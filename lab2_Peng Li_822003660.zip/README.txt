This folder include files for lab2.
Using $make to compile the code and $make clean to clean up the make files.
The "Number Generator" folder has the random/sorted number generator program.

